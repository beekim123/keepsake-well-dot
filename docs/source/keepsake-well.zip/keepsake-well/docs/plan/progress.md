# 进度日志

开发者每次提交后在**最上面**追加一条。格式：

```text
## YYYY-MM-DD · 简短标题
- 做了什么：
- 提交：<hash>
- 截图 / 对照表：artifacts/screenshots/... 或 resources/art/export/sheets/...
- 改了哪些【建议】及理由：
- 下一步：
```

---

（尚未开工）
